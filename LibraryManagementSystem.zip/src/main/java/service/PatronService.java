package service;

import model.Patron;

import java.util.*;
import java.util.logging.Logger;

public class PatronService {
    private static final Logger LOGGER = Logger.getLogger(PatronService.class.getName());

    private final Map<String, Patron> patrons = new HashMap<>();

    public void addPatron(Patron p) {
        patrons.put(p.getId(), p);
        LOGGER.info("Added patron: " + p);
    }

    public Optional<Patron> findById(String id) { return Optional.ofNullable(patrons.get(id)); }

    public void updatePatronName(String id, String name) {
        Patron p = patrons.get(id);
        if (p != null) {
            p.setName(name);
            LOGGER.info("Updated patron: " + p);
        }
    }

    public Collection<Patron> listAll() { return patrons.values(); }
}

package service;

import model.Book;
import model.Patron;
import strategy.RecommendationStrategy;

import java.util.List;
import java.util.logging.Logger;

public class RecommendationService {
    private static final Logger LOGGER = Logger.getLogger(RecommendationService.class.getName());

    private RecommendationStrategy strategy;

    public RecommendationService(RecommendationStrategy strategy) {
        this.strategy = strategy;
    }

    public void setStrategy(RecommendationStrategy strategy) { this.strategy = strategy; }

    public List<Book> recommend(Patron p, List<Book> catalog) {
        LOGGER.info("Generating recommendations for " + p.getId());
        return strategy.recommend(p, catalog);
    }
}

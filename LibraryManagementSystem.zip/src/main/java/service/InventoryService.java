package service;

import model.Book;

import java.util.*;
import java.util.logging.Logger;
import java.util.stream.Collectors;

public class InventoryService {
    private static final Logger LOGGER = Logger.getLogger(InventoryService.class.getName());

    private final Map<String, Book> isbnMap = new HashMap<>();

    public void addBook(Book b) {
        isbnMap.put(b.getIsbn(), b);
        LOGGER.info("Added book: " + b);
    }

    public void removeBook(String isbn) {
        Book removed = isbnMap.remove(isbn);
        LOGGER.info("Removed book: " + removed);
    }

    public Optional<Book> findByIsbn(String isbn) { return Optional.ofNullable(isbnMap.get(isbn)); }

    public List<Book> searchByTitle(String title) {
        String t = title.toLowerCase();
        return isbnMap.values().stream().filter(b -> b.getTitle().toLowerCase().contains(t)).collect(Collectors.toList());
    }

    public List<Book> searchByAuthor(String author) {
        String a = author.toLowerCase();
        return isbnMap.values().stream().filter(b -> b.getAuthor().toLowerCase().contains(a)).collect(Collectors.toList());
    }

    public List<Book> listAll() { return new ArrayList<>(isbnMap.values()); }

    public void updateBook(String isbn, String title, String author, int year) {
        Book b = isbnMap.get(isbn);
        if (b != null) {
            b.setTitle(title);
            b.setAuthor(author);
            b.setPublicationYear(year);
            LOGGER.info("Updated book: " + b);
        }
    }

    public void setAvailability(String isbn, boolean available) {
        Book b = isbnMap.get(isbn);
        if (b != null) b.setAvailable(available);
    }
}

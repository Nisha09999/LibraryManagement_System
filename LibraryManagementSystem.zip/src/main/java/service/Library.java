package service;

import factory.ModelFactory;
import model.Book;
import model.Patron;
import observer.Observer;
import strategy.SimpleHistoryBasedStrategy;

import java.util.List;
import java.util.logging.Logger;

public class Library {
    private static final Logger LOGGER = Logger.getLogger(Library.class.getName());

    private final InventoryService inventory = new InventoryService();
    private final PatronService patronService = new PatronService();
    private final NotificationService notificationService = new NotificationService();
    private final LendingService lendingService = new LendingService(inventory, patronService, notificationService);
    private final RecommendationService recommendationService = new RecommendationService(new SimpleHistoryBasedStrategy());

    public InventoryService getInventory() { return inventory; }
    public PatronService getPatronService() { return patronService; }
    public LendingService getLendingService() { return lendingService; }
    public RecommendationService getRecommendationService() { return recommendationService; }
    public NotificationService getNotificationService() { return notificationService; }

    // convenience helpers
    public void addBook(String isbn, String title, String author, int year) {
        Book b = ModelFactory.createBook(isbn, title, author, year);
        inventory.addBook(b);
    }

    public void addPatron(String id, String name) {
        Patron p = ModelFactory.createPatron(id, name);
        patronService.addPatron(p);
        // register patron for notifications
        notificationService.register((Observer) p);
    }

    public List<Book> recommendForPatron(String patronId) {
        return patronService.findById(patronId).map(p -> recommendationService.recommend(p, inventory.listAll())).orElse(List.of());
    }
}

package service;

import observer.Observer;
import observer.Subject;

import java.util.*;
import java.util.logging.Logger;

public class NotificationService implements Subject {
    private static final Logger LOGGER = Logger.getLogger(NotificationService.class.getName());

    // We'll register patrons (Observers) here
    private final Set<Observer> observers = new HashSet<>();

    @Override
    public void register(Observer o) { observers.add(o); }
    @Override
    public void unregister(Observer o) { observers.remove(o); }
    @Override
    public void notifyObservers(String message) {
        LOGGER.info("Notifying observers: " + message);
        observers.forEach(o -> o.update(message));
    }

    // Convenience to send to single observer
    public void notifyObserver(Observer o, String message) {
        LOGGER.info("Notifying single observer: " + message);
        o.update(message);
    }
}

package service;

import model.Book;
import model.BorrowRecord;
import model.Patron;
import model.Reservation;
import observer.Observer;

import java.time.LocalDate;
import java.util.*;
import java.util.logging.Logger;
import java.util.stream.Collectors;

public class LendingService {
    private static final Logger LOGGER = Logger.getLogger(LendingService.class.getName());

    private final InventoryService inventory;
    private final PatronService patronService;
    private final NotificationService notificationService;

    // active borrowings: isbn -> BorrowRecord
    private final Map<String, BorrowRecord> activeBorrows = new HashMap<>();

    // reservations queue by ISBN
    private final Map<String, Queue<Reservation>> reservations = new HashMap<>();

    public LendingService(InventoryService inventory, PatronService patronService, NotificationService notificationService) {
        this.inventory = inventory;
        this.patronService = patronService;
        this.notificationService = notificationService;
    }

    public boolean checkout(String patronId, String isbn) {
        Optional<Patron> pop = patronService.findById(patronId);
        Optional<Book> bop = inventory.findByIsbn(isbn);
        if (pop.isEmpty() || bop.isEmpty()) return false;
        Patron p = pop.get();
        Book b = bop.get();
        if (!b.isAvailable()) {
            LOGGER.info("Book not available -> placing reservation for patron " + patronId);
            reserve(patronId, isbn);
            return false;
        }
        b.setAvailable(false);
        BorrowRecord rec = new BorrowRecord(patronId, isbn);
        activeBorrows.put(isbn, rec);
        p.addBorrowRecord(rec);
        LOGGER.info("Checked out: " + rec);
        return true;
    }

    public boolean returnBook(String isbn) {
        BorrowRecord rec = activeBorrows.remove(isbn);
        if (rec == null) {
            LOGGER.warning("Attempt to return non-borrowed book: " + isbn);
            return false;
        }
        rec.setReturnDate(LocalDate.now());
        inventory.setAvailability(isbn, true);
        LOGGER.info("Returned: " + rec);

        // If reservations exist, notify next patron
        Queue<Reservation> q = reservations.get(isbn);
        if (q != null && !q.isEmpty()) {
            Reservation next = q.poll();
            // find observer (patron)
            Optional<Patron> p = patronService.findById(next.getPatronId());
            p.ifPresent(patron -> notificationService.notifyObserver((Observer) patron, "Reserved book available: " + isbn));
            // For simplicity, we'll mark available but business rules can vary.
            inventory.setAvailability(isbn, true);
        }

        return true;
    }

    public void reserve(String patronId, String isbn) {
        reservations.computeIfAbsent(isbn, k -> new LinkedList<>()).offer(new Reservation(patronId, isbn));
        LOGGER.info("Reservation added: " + patronId + " -> " + isbn);
    }

    public List<Reservation> getReservations(String isbn) {
        Queue<Reservation> q = reservations.get(isbn);
        if (q == null) return Collections.emptyList();
        return q.stream().collect(Collectors.toList());
    }

    public boolean isBorrowed(String isbn) { return activeBorrows.containsKey(isbn); }
}

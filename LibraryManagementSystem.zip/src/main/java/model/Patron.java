package model;

import observer.Observer;

import java.util.*;
import java.util.logging.Logger;

public class Patron implements Observer {
    private static final Logger LOGGER = Logger.getLogger(Patron.class.getName());

    private final String id;
    private String name;
    private final List<BorrowRecord> borrowHistory = new ArrayList<>();
    private final Queue<String> notifications = new LinkedList<>();

    public Patron(String id, String name) {
        this.id = id;
        this.name = name;
    }

    public String getId() { return id; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public List<BorrowRecord> getBorrowHistory() { return Collections.unmodifiableList(borrowHistory); }
    public void addBorrowRecord(BorrowRecord record) { borrowHistory.add(record); }

    // Observer method
    @Override
    public void update(String message) {
        LOGGER.info("Notification for patron " + id + ": " + message);
        notifications.add(message);
    }

    public List<String> drainNotifications() {
        List<String> out = new ArrayList<>();
        while (!notifications.isEmpty()) out.add(notifications.poll());
        return out;
    }

    @Override
    public String toString() { return String.format("Patron[%s | %s]", id, name); }
}

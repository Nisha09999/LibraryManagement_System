package model;

import java.time.LocalDate;

public class BorrowRecord {
    private final String patronId;
    private final String isbn;
    private final LocalDate checkoutDate;
    private LocalDate returnDate;

    public BorrowRecord(String patronId, String isbn) {
        this.patronId = patronId;
        this.isbn = isbn;
        this.checkoutDate = LocalDate.now();
    }

    public String getPatronId() { return patronId; }
    public String getIsbn() { return isbn; }
    public LocalDate getCheckoutDate() { return checkoutDate; }
    public LocalDate getReturnDate() { return returnDate; }
    public void setReturnDate(LocalDate returnDate) { this.returnDate = returnDate; }

    @Override
    public String toString() {
        return String.format("BorrowRecord[patron=%s, isbn=%s, out=%s, ret=%s]", patronId, isbn, checkoutDate, returnDate);
    }
}

package model;

import java.time.LocalDateTime;

public class Reservation {
    private final String patronId;
    private final String isbn;
    private final LocalDateTime timestamp;

    public Reservation(String patronId, String isbn) {
        this.patronId = patronId;
        this.isbn = isbn;
        this.timestamp = LocalDateTime.now();
    }

    public String getPatronId() { return patronId; }
    public String getIsbn() { return isbn; }
    public LocalDateTime getTimestamp() { return timestamp; }

    @Override
    public String toString() { return String.format("Reservation[%s -> %s at %s]", patronId, isbn, timestamp); }
}

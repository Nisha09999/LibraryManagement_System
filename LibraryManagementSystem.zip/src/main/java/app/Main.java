package app;

import service.Library;

import java.util.logging.LogManager;

public class Main {
    public static void main(String[] args) {
        // minimal logging configuration (uses java.util.logging defaults)
        LogManager.getLogManager().reset();

        Library lib = new Library();

        // seed data
        lib.addBook("978-0134685991", "Effective Java", "Joshua Bloch", 2018);
        lib.addBook("978-0596009205", "Head First Java", "Kathy Sierra", 2005);
        lib.addBook("978-0201633610", "Design Patterns", "Erich Gamma", 1994);

        lib.addPatron("P1", "Alice");
        lib.addPatron("P2", "Bob");

        // Alice checks out Effective Java
        lib.getLendingService().checkout("P1", "978-0134685991");

        // Bob tries to checkout same book -> will be reserved
        lib.getLendingService().checkout("P2", "978-0134685991");

        // Alice returns book -> Bob should be notified
        lib.getLendingService().returnBook("978-0134685991");

        // Recommendations for Bob
        var recs = lib.recommendForPatron("P2");
        System.out.println("Recommendations for P2: " + recs);
    }
}

package factory;

import model.Book;
import model.Patron;

public class ModelFactory {
    public static Book createBook(String isbn, String title, String author, int year) {
        return new Book(isbn, title, author, year);
    }
    public static Patron createPatron(String id, String name) {
        return new Patron(id, name);
    }
}

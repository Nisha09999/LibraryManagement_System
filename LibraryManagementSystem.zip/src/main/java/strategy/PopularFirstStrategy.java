package strategy;

import model.Book;
import model.Patron;

import java.util.*;
import java.util.stream.Collectors;

public class PopularFirstStrategy implements RecommendationStrategy {
    // In-memory popularity heuristic: sort by publication year (newer = "popular")
    @Override
    public List<Book> recommend(Patron p, List<Book> catalog) {
        return catalog.stream()
                .filter(Book::isAvailable)
                .sorted(Comparator.comparingInt(Book::getPublicationYear).reversed())
                .collect(Collectors.toList());
    }
}

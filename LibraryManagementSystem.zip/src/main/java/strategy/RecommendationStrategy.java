package strategy;

import model.Book;
import model.Patron;

import java.util.List;

public interface RecommendationStrategy {
    List<Book> recommend(Patron p, List<Book> catalog);
}

package strategy;

import model.Book;
import model.Patron;
import model.BorrowRecord;

import java.util.*;
import java.util.stream.Collectors;

public class SimpleHistoryBasedStrategy implements RecommendationStrategy {
    @Override
    public List<Book> recommend(Patron p, List<Book> catalog) {
        // naive approach: recommend books by authors the patron borrowed most
        Map<String, Long> authorScore = new HashMap<>();
        for (BorrowRecord br : p.getBorrowHistory()) {
            for (Book b : catalog) {
                if (b.getIsbn().equals(br.getIsbn())) {
                    authorScore.merge(b.getAuthor(), 1L, Long::sum);
                }
            }
        }
        List<String> favoriteAuthors = authorScore.entrySet().stream()
                .sorted(Map.Entry.<String, Long>comparingByValue().reversed())
                .map(Map.Entry::getKey)
                .collect(Collectors.toList());

        List<Book> result = new ArrayList<>();
        for (String a : favoriteAuthors) {
            for (Book b : catalog) if (b.getAuthor().equals(a) && b.isAvailable()) result.add(b);
        }
        return result;
    }
}
